
/**
 * Provides resources for representing and exchanging data about the main entities of the 
 * application.
 *
 * @author leoforfriends
 * @version 1.00
 * @since 1.00
 */
package it.unipd.dei.webapp.leoforfriends.resource;