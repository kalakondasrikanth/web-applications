/**
 * Provides access to the database.
 *
 * @author leoforfriends
 * @version 1.00
 * @since 1.00
 */
package it.unipd.dei.webapp.leoforfriends.database;