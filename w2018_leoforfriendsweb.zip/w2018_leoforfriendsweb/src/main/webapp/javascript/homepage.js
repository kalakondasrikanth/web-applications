if (str != "" && str != null)
{
    $("#logprof").html("<i class=\"fa fa-user\"></i> "+ str);
}